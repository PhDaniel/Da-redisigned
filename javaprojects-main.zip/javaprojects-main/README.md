Steps for Pulling the source code
1. git clone https://github.com/drjeffgeoff/javaprojects.git
