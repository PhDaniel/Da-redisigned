//Outputs

public class exampleOne {
    public static void main(String[] args) {
        // Arithematic Operators
        int a = 10;
        int b = 5;
        // Addition
        int sum = a + b;

        // Subtraction
        int difference = a - b;

        // Multiplication
        int product = a * b;

        // Division
        int quotient = a / b;

        // Modulus
        int remainder = a % b;

        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);
        System.out.println("Product: " + product);
        System.out.println("Quotient: " + quotient);
        System.out.println("Remainder: " + remainder);

        System.out.println("Sum: " + sum);
    }
}
